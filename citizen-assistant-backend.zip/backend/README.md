# Voice & Multilingual AI Assistant — Week 6

Offline-first multilingual voice interface for the citizen assistant.
Implements the full pipeline from the Week 6 plan:

```
Voice/Text Input → Whisper Tiny (STT + language ID) → Language Manager →
Eligibility + RAG (pluggable hooks) → Conversation Memory → Gemini →
Response Formatter → AI4Bharat Indic Parler-TTS → Voice Output
```

## Folder structure

```
backend/
├── speech/
│   ├── whisper_service.py     # faster-whisper wrapper (STT + language ID)
│   ├── transcription.py       # STT pipeline orchestration
│   ├── language_detector.py   # text-input language detection (langdetect)
│   └── audio_utils.py         # decode/resample/VAD/encode helpers
├── multilingual/
│   ├── language_manager.py    # sticky per-session language state
│   ├── prompt_builder.py      # language-aware Gemini system prompts
│   ├── response_formatter.py  # cleans LLM output for display vs. speech
│   └── ai_processor.py        # Gemini call + eligibility/RAG hook points
├── tts/
│   ├── parler_service.py      # AI4Bharat Indic Parler-TTS wrapper
│   ├── voice_generator.py     # per-language voice descriptions
│   └── audio_output.py        # WAV / base64 encoding of output audio
├── memory/
│   └── session_manager.py     # conversation history, citizen profile
├── api/
│   ├── speech.py              # POST /speech/transcribe, /chat, /speak
│   └── language.py            # GET/PUT /language
├── main.py                    # FastAPI app
├── requirements.txt
└── .env.example
```

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

# Parler-TTS isn't a stable PyPI release yet — install from source:
pip install git+https://github.com/huggingface/parler-tts.git

cp .env.example .env
# then edit .env and add your GEMINI_API_KEY
```

First run will download two models from HuggingFace:
- `Systran/faster-whisper-tiny` (~75 MB)
- `ai4bharat/indic-parler-tts` (several GB — this is the heavy one; give it
  time and disk space, especially over a slow connection)

## Run

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Visit `http://localhost:8000/docs` for interactive API docs (Swagger UI).

## Endpoints

| Method | Path                 | Purpose                                      |
|--------|----------------------|-----------------------------------------------|
| GET    | `/health`            | Service status, supported languages, TTS availability |
| POST   | `/speech/transcribe` | Voice → text + language + confidence          |
| POST   | `/speech/chat`       | Full pipeline: voice/text in → voice/text out |
| POST   | `/speech/speak`      | Text → speech only (no AI processing)         |
| GET    | `/language`          | Get a session's current language              |
| PUT    | `/language`          | Explicitly set a session's language           |

### Example: full voice conversation turn

```bash
curl -X POST http://localhost:8000/speech/chat \
  -F "session_id=citizen-123" \
  -F "audio=@query.wav"
```

Response:
```json
{
  "session_id": "citizen-123",
  "query_text": "मला शेतकरी योजनेची माहिती पाहिजे",
  "response_text": "...",
  "language": "mr",
  "audio_base64": "UklGRi...",
  "audio_sample_rate": 24000
}
```

### Example: text-only turn (no mic needed, useful for testing)

```bash
curl -X POST http://localhost:8000/speech/chat \
  -F "session_id=citizen-123" \
  -F "text=What is PM-KISAN?"
```

## Wiring in the Eligibility Engine and RAG modules

Those are owned by other pipeline members per the architecture diagram.
`multilingual/ai_processor.py` exposes two hook points — set these once at
app startup (e.g. in `main.py`) once those modules exist:

```python
from multilingual import ai_processor

def my_rag_retriever(query: str, language: str) -> str | None:
    ...  # return relevant scheme text chunks from ChromaDB

def my_eligibility_engine(query: str, language: str, citizen_profile: dict | None) -> str | None:
    ...  # return an eligibility note, or None

ai_processor.rag_retriever = my_rag_retriever
ai_processor.eligibility_engine = my_eligibility_engine
```

Until they're wired in, `/speech/chat` still works end-to-end — Gemini just
answers from general knowledge instead of retrieved scheme documents, so you
can develop and test the voice pipeline independently.

## Notes on the 8GB RAM / CPU-only target

- Whisper runs as `tiny` with `int8` quantization (see `whisper_service.py`)
  — this is the lightest real Whisper variant, chosen deliberately per the
  spec's constraint.
- Both models (Whisper + Parler) load **lazily** on first request, not at
  app startup, so `uvicorn` boots fast and you're not holding ~2 models in
  RAM if you're only testing text-only chat.
- If Parler-TTS isn't installed yet in your environment, `/speech/chat`
  degrades gracefully — you still get `response_text` back, with
  `audio_base64` empty, rather than a hard failure. `/speech/speak` will
  return a 503 with a clear message telling you what to install.

## Week 7 — Explainability & Trust Engine

Every AI answer can now be wrapped with evidence, reasoning, citations,
confidence, freshness checks, and conflict detection — so citizens never
have to blindly trust a response.

```
backend/
├── models/
│   ├── evidence.py       # Evidence object (source, section, page, dates)
│   ├── citation.py       # Citation object
│   ├── confidence.py     # ConfidenceLevel enum + Confidence object
│   └── explanation.py    # Combined ExplainableResponse
├── explainability/
│   ├── evidence.py           # Module 1 — Evidence Collection (+ RAG hook)
│   ├── reasoning.py          # Module 2 — Reason Generator (+ eligibility hook)
│   ├── citations.py          # Module 3 & 8 — Citations + Official Links
│   ├── confidence.py         # Module 4 — Confidence Engine
│   ├── conflict_detector.py  # Module 5 — Source Conflict Detector
│   ├── freshness.py          # Module 6 — Freshness Checker
│   ├── transparency.py       # Module 7 — Transparency Layer
│   ├── formatter.py          # Module 9 — Explainable Response Formatter
│   └── service.py            # Orchestrates the full pipeline + in-memory store
└── api/
    └── explainability.py     # Module 10 — POST /explain, GET /sources|confidence|citations
```

### Endpoints

| Method | Path                          | Purpose                                         |
|--------|-------------------------------|--------------------------------------------------|
| POST   | `/explain`                    | Wraps a (query, answer) pair with full explainability |
| GET    | `/sources/{scheme_id}`        | Sources behind the latest explanation for a scheme |
| GET    | `/confidence/{response_id}`   | Confidence block for a stored response          |
| GET    | `/citations/{response_id}`    | Citations for a stored response                 |

### How it connects to Week 6

`/explain` doesn't generate the answer itself — it explains one that
already exists. The intended flow is:

```bash
# 1. Get an answer from the voice/chat pipeline (Week 6)
curl -X POST http://localhost:8000/speech/chat \
  -F "session_id=citizen-123" -F "text=Am I eligible for PM-KISAN?"
# -> { "response_text": "...", ... }

# 2. Wrap that answer with explainability (Week 7)
curl -X POST http://localhost:8000/explain \
  -H "Content-Type: application/json" \
  -d '{
        "query": "Am I eligible for PM-KISAN?",
        "answer_text": "<response_text from step 1>",
        "citizen_profile": {"occupation": "Farmer", "state": "Maharashtra", "income": 150000},
        "scheme_id": "pm-kisan"
      }'
```

Response matches the spec's format exactly:

```json
{
  "response_id": "...",
  "scheme_id": "pm-kisan",
  "answer": "...",
  "reason": ["You selected Farmer as your occupation.", "..."],
  "sources": [{"title": "PM-KISAN Portal", "url": "https://pmkisan.gov.in", "last_verified": "2026-08-07", "...": "..."}],
  "confidence": {"level": "High", "reason": "...", "score": 0.97},
  "official_links": ["https://pmkisan.gov.in"],
  "last_updated": "2026-08-07",
  "transparency_trace": ["Government documents retrieved", "..."],
  "conflict_warning": null
}
```

### Wiring in the real Eligibility Engine and RAG modules

Same pluggable-hook pattern as Week 6's `ai_processor.py`. Until these are
wired in, both default to small mock implementations (PM-KISAN evidence)
so the whole pipeline is testable standalone:

```python
from explainability import evidence as evidence_module
from explainability import reasoning as reasoning_module

def my_rag_retriever(query: str, language: str) -> list[dict]:
    ...  # return evidence dicts: scheme_id, chunk_id, source_title,
         # source_url, section, page, last_verified, rule_id,
         # relevance_score, human_verified, text

def my_eligibility_engine(query: str, language: str, citizen_profile: dict | None) -> list[dict]:
    ...  # return [{"criterion": ..., "matched": bool, "detail": ...}, ...]

evidence_module.rag_retriever = my_rag_retriever
reasoning_module.eligibility_engine = my_eligibility_engine
```

### Design notes

- **Confidence is never a guessed probability.** It's a weighted score
  built from source count, human-verification status, retrieval
  relevance, conflict presence, and staleness — always shown with a
  plain-language reason, per the spec's core principle.
- **Conflict detection** extracts numeric amounts (₹, lakh, crore) from
  evidence text grouped by `rule_id` and flags disagreement — this is what
  catches the spec's "₹2 lakh vs ₹2.5 lakh" example automatically.
- **Freshness** treats evidence with no `last_verified` date as stale by
  default, not fresh — an unknown verification date shouldn't quietly
  boost confidence.
- **Citations never fabricate.** `official_links` only ever contains real
  URLs that came through as evidence; if nothing is on a `.gov.in` domain,
  it falls back to whatever real sources exist rather than inventing one.

