"""
main.py
Entry point for the Voice & Multilingual AI backend (Week 6).

Run locally:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

Environment variables (see .env.example):
    GEMINI_API_KEY   - required for /speech/chat
    GEMINI_MODEL     - optional, defaults to gemini-2.0-flash
"""

from __future__ import annotations

import logging

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("main")

from api import explainability as explainability_api
from api import language as language_api
from api import speech as speech_api
from speech.whisper_service import SUPPORTED_LANGUAGES
from tts.parler_service import is_available as tts_available

app = FastAPI(
    title="Voice & Multilingual AI Assistant",
    description="Offline-first multilingual voice interface for Indian government scheme discovery.",
    version="1.0.0",
)

# CORS wide-open for local dev / hackathon deployment — tighten this to your
# actual frontend origin(s) before shipping to production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(speech_api.router)
app.include_router(language_api.router)
app.include_router(explainability_api.router)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "supported_languages": SUPPORTED_LANGUAGES,
        "tts_model_installed": tts_available(),
    }


@app.on_event("startup")
async def startup_event():
    logger.info("Voice & Multilingual AI backend starting up.")
    logger.info(
        "Note: Whisper and Parler-TTS models load lazily on first request, "
        "not at startup, to keep boot time fast."
    )
