"""
language_manager.py
Keeps track of each session's preferred language across a conversation, so a
citizen doesn't have to re-establish language on every single turn — once
Whisper (or the text-language-detector) determines it, it "sticks" until
they explicitly switch (via PUT /language or by speaking a different
language clearly enough to override).

Storage is in-memory (dict) for simplicity; swap `_store` for a Redis-backed
implementation if you need multi-process / multi-worker deployment.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field

from speech.whisper_service import SUPPORTED_LANGUAGES

DEFAULT_LANGUAGE = "en"

# Only override a "sticky" session language automatically if the newly
# detected language is at least this confident — avoids a single noisy
# utterance flipping a citizen's whole session to the wrong language.
AUTO_SWITCH_CONFIDENCE_THRESHOLD = 0.75


@dataclass
class LanguageState:
    language: str = DEFAULT_LANGUAGE
    locked: bool = False  # True once the user explicitly sets language via PUT /language


class LanguageManager:
    def __init__(self) -> None:
        self._store: dict[str, LanguageState] = {}
        self._lock = threading.Lock()

    def get_language(self, session_id: str) -> str:
        with self._lock:
            state = self._store.get(session_id)
            return state.language if state else DEFAULT_LANGUAGE

    def set_language(self, session_id: str, language: str, *, explicit: bool = True) -> str:
        """Set a session's language.

        explicit=True (e.g. from PUT /language, or a high-confidence Whisper
        detection) locks the language so lower-confidence guesses on later
        turns won't silently change it.
        """
        if language not in SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language '{language}'. Supported: {list(SUPPORTED_LANGUAGES)}")

        with self._lock:
            state = self._store.setdefault(session_id, LanguageState())
            if state.locked and not explicit:
                return state.language
            state.language = language
            if explicit:
                state.locked = True
            return state.language

    def maybe_update_from_detection(self, session_id: str, detected_language: str, confidence: float) -> str:
        """Called after every STT/text-detection pass. Only actually changes
        the sticky session language if confidence clears the threshold and
        the language wasn't explicitly locked by the user.
        """
        if detected_language not in SUPPORTED_LANGUAGES:
            return self.get_language(session_id)

        with self._lock:
            state = self._store.setdefault(session_id, LanguageState())
            if state.locked:
                return state.language
            if confidence >= AUTO_SWITCH_CONFIDENCE_THRESHOLD:
                state.language = detected_language
            return state.language

    def list_supported(self) -> dict:
        return dict(SUPPORTED_LANGUAGES)


# module-level singleton used by the API layer
language_manager = LanguageManager()
