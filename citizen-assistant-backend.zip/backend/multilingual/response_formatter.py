"""
response_formatter.py
Gemini's raw output is fine for a text UI but needs light cleanup before
being handed to the TTS engine — no markdown, no bullet symbols, sentence
breaks normalized so Parler doesn't stumble on stray formatting characters.
"""

from __future__ import annotations

import re

_MARKDOWN_PATTERNS = [
    (re.compile(r"\*\*(.*?)\*\*"), r"\1"),   # **bold**
    (re.compile(r"\*(.*?)\*"), r"\1"),       # *italic*
    (re.compile(r"`(.*?)`"), r"\1"),         # `code`
    (re.compile(r"^[-*•]\s+", re.MULTILINE), ""),  # bullet markers
    (re.compile(r"#+\s*"), ""),              # headings
]


def format_for_display(raw_text: str) -> str:
    """Minimal cleanup for the text response returned to the client
    (trims whitespace, collapses blank lines) — markdown is fine to keep here
    since a text UI can render it.
    """
    text = raw_text.strip()
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text


def format_for_speech(raw_text: str) -> str:
    """Strips anything that would make Parler TTS mispronounce or stumble:
    markdown symbols, multiple consecutive spaces/newlines, etc.
    """
    text = raw_text
    for pattern, repl in _MARKDOWN_PATTERNS:
        text = pattern.sub(repl, text)

    text = re.sub(r"\s+", " ", text).strip()
    return text
