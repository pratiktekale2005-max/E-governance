"""
ai_processor.py
Module 3 (AI Processing) from the spec. This ties together:
  Eligibility Engine -> RAG Retrieval -> Conversation Memory -> Gemini

The eligibility engine and RAG retrieval are treated as pluggable hooks
here (they're owned by other members of the team per the architecture
diagram) — this module defines the interface it expects from them and
falls back to a no-op if they aren't wired in yet, so the voice pipeline
is runnable standalone.

Wire your real implementations in by setting:
    ai_processor.eligibility_engine = your_eligibility_fn
    ai_processor.rag_retriever = your_rag_fn
"""

from __future__ import annotations

import logging
import os
from typing import Callable, Optional

from google import genai
from google.genai import types as genai_types

from .prompt_builder import build_messages
from .response_formatter import format_for_display, format_for_speech

logger = logging.getLogger("multilingual.ai_processor")

GEMINI_MODEL_NAME = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")

# --- Pluggable hooks (owned by other pipeline modules) ---------------------
# Signature: (query: str, language: str, citizen_profile: dict | None) -> str | None
EligibilityFn = Callable[[str, str, Optional[dict]], Optional[str]]
RagFn = Callable[[str, str], Optional[str]]

eligibility_engine: Optional[EligibilityFn] = None
rag_retriever: Optional[RagFn] = None


def _get_client() -> genai.Client:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not set. Add it to your environment or .env file before calling the AI pipeline."
        )
    return genai.Client(api_key=api_key)


def _gather_context(query: str, language: str, citizen_profile: dict | None) -> str | None:
    """Runs the eligibility + RAG hooks (if configured) and merges whatever
    they return into a single context block for the prompt builder.
    """
    context_chunks = []

    if rag_retriever is not None:
        try:
            rag_context = rag_retriever(query, language)
            if rag_context:
                context_chunks.append(rag_context)
        except Exception:
            logger.exception("RAG retrieval hook failed; continuing without it.")

    if eligibility_engine is not None:
        try:
            eligibility_note = eligibility_engine(query, language, citizen_profile)
            if eligibility_note:
                context_chunks.append(f"Eligibility notes: {eligibility_note}")
        except Exception:
            logger.exception("Eligibility engine hook failed; continuing without it.")

    return "\n\n".join(context_chunks) if context_chunks else None


def _messages_to_gemini_contents(messages: list[dict]) -> tuple[str | None, list[genai_types.Content]]:
    """Gemini's SDK wants system instructions separate from the turn history,
    and uses role 'model' instead of 'assistant'.
    """
    system_instruction = None
    contents: list[genai_types.Content] = []
    for m in messages:
        if m["role"] == "system":
            system_instruction = m["content"]
        elif m["role"] == "user":
            contents.append(genai_types.Content(role="user", parts=[genai_types.Part.from_text(text=m["content"])]))
        elif m["role"] == "assistant":
            contents.append(genai_types.Content(role="model", parts=[genai_types.Part.from_text(text=m["content"])]))
    return system_instruction, contents


def generate_response(
    query: str,
    language: str,
    conversation_history: list[dict] | None = None,
    citizen_profile: dict | None = None,
) -> dict:
    """Runs the full AI processing stage and returns both a display-ready
    and a speech-ready version of the answer.

    Returns: {"text": <for UI>, "speech_text": <for TTS>, "language": ...}
    """
    client = _get_client()

    context = _gather_context(query, language, citizen_profile)
    messages = build_messages(language, query, conversation_history, retrieved_context=context)
    system_instruction, contents = _messages_to_gemini_contents(messages)

    result = client.models.generate_content(
        model=GEMINI_MODEL_NAME,
        contents=contents,
        config=genai_types.GenerateContentConfig(system_instruction=system_instruction),
    )
    raw_text = result.text or ""

    return {
        "text": format_for_display(raw_text),
        "speech_text": format_for_speech(raw_text),
        "language": language,
    }
