"""
models/evidence.py
Data model for a single piece of retrieved evidence backing an AI response.
Mirrors the "Evidence Object" shape from the Week 7 spec.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel, Field


class Evidence(BaseModel):
    scheme_id: str
    chunk_id: str
    source_title: str
    source_url: str
    department: Optional[str] = None
    section: Optional[str] = None
    page: Optional[int] = None
    retrieved_at: date
    last_verified: Optional[date] = None
    rule_id: Optional[str] = None
    relevance_score: float = Field(default=0.0, ge=0.0, le=1.0)
    human_verified: bool = False
    # The actual retrieved chunk text. Used internally by reasoning/
    # conflict-detection; not necessarily shown to the citizen verbatim.
    text: Optional[str] = None
