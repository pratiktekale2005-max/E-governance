"""
models/explanation.py
The final combined "Explainable Response" shape returned by POST /explain —
matches the response_format JSON in the Week 7 spec, plus a response_id
so it can be looked up later via GET /sources, /confidence, /citations.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel

from .citation import Citation
from .confidence import Confidence


class ExplainableResponse(BaseModel):
    response_id: str
    scheme_id: Optional[str] = None
    answer: str
    reason: list[str]
    sources: list[Citation]
    confidence: Confidence
    official_links: list[str]
    last_updated: date
    transparency_trace: list[str]
    conflict_warning: Optional[str] = None
