"""
models/citation.py
Data model for a single government source citation attached to a response.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel


class Citation(BaseModel):
    title: str
    department: Optional[str] = None
    url: str
    section: Optional[str] = None
    page: Optional[int] = None
    last_verified: Optional[date] = None
