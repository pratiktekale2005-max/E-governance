"""
models/confidence.py
Data model for the confidence block attached to every explainable response.
Levels are qualitative (High/Medium/Low) with a plain-language reason —
per the spec, we explain confidence rather than just showing a number.
`score` is kept as an internal 0-1 aggregate for tuning/debugging; it is
not the citizen-facing signal.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class ConfidenceLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class Confidence(BaseModel):
    level: ConfidenceLevel
    reason: str
    score: float
