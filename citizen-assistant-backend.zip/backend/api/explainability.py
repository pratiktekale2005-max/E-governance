"""
api/explainability.py
Module 10 — Explainability APIs.

  POST /explain                   -> full explainable response for a (query, answer) pair
  GET  /sources/{scheme_id}       -> sources behind the latest explanation for a scheme
  GET  /confidence/{response_id}  -> confidence block for a previously generated response
  GET  /citations/{response_id}   -> citations for a previously generated response
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from explainability.service import generate_explanation, store
from models.citation import Citation
from models.confidence import Confidence
from models.explanation import ExplainableResponse

router = APIRouter(tags=["explainability"])


class ExplainRequest(BaseModel):
    query: str
    answer_text: str
    language: str = "en"
    citizen_profile: dict | None = None
    scheme_id: str | None = None


@router.post("/explain", response_model=ExplainableResponse)
async def explain(body: ExplainRequest):
    if not body.query.strip():
        raise HTTPException(status_code=400, detail="query must not be empty.")
    if not body.answer_text.strip():
        raise HTTPException(status_code=400, detail="answer_text must not be empty.")

    return generate_explanation(
        query=body.query,
        language=body.language,
        answer_text=body.answer_text,
        citizen_profile=body.citizen_profile,
        scheme_id=body.scheme_id,
    )


@router.get("/sources/{scheme_id}", response_model=list[Citation])
async def get_sources(scheme_id: str):
    response = store.get_latest_for_scheme(scheme_id)
    if response is None:
        raise HTTPException(status_code=404, detail=f"No explanation found for scheme_id '{scheme_id}'.")
    return response.sources


@router.get("/confidence/{response_id}", response_model=Confidence)
async def get_confidence(response_id: str):
    response = store.get(response_id)
    if response is None:
        raise HTTPException(status_code=404, detail=f"No response found with id '{response_id}'.")
    return response.confidence


@router.get("/citations/{response_id}", response_model=list[Citation])
async def get_citations(response_id: str):
    response = store.get(response_id)
    if response is None:
        raise HTTPException(status_code=404, detail=f"No response found with id '{response_id}'.")
    return response.sources
