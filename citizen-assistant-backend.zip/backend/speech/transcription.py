"""
transcription.py
Orchestrates the full Speech-to-Text step: raw upload bytes -> preprocessed
audio -> Whisper -> structured result. This is what api/speech.py calls for
POST /speech/transcribe, and it's also the first stage inside /speech/chat
when the request contains audio.
"""

from __future__ import annotations

import logging

from .audio_utils import preprocess_upload, TARGET_SAMPLE_RATE
from .whisper_service import transcribe_audio, TranscriptionResult

logger = logging.getLogger("speech.transcription")

MIN_CONFIDENCE_WARNING = 0.5


class TranscriptionError(Exception):
    """Raised when the pipeline can't produce a usable transcription
    (e.g. empty/near-silent audio)."""


def run_stt_pipeline(raw_audio_bytes: bytes, hint_language: str | None = None) -> TranscriptionResult:
    """Full pipeline: decode -> resample -> VAD trim -> transcribe.

    Raises TranscriptionError if the resulting text is empty, so callers
    (the API layer) can return a clean 422 instead of silently passing
    empty text down the AI pipeline.
    """
    audio = preprocess_upload(raw_audio_bytes)

    if len(audio) < TARGET_SAMPLE_RATE * 0.2:  # less than ~200ms of audio
        raise TranscriptionError("Audio too short or silent after trimming — please try again.")

    result = transcribe_audio(audio, sample_rate=TARGET_SAMPLE_RATE, hint_language=hint_language)

    if not result.text:
        raise TranscriptionError("Could not detect any speech in the provided audio.")

    if result.confidence < MIN_CONFIDENCE_WARNING:
        logger.warning(
            "Low-confidence transcription (%.2f): %r [%s]",
            result.confidence, result.text, result.language,
        )

    return result
