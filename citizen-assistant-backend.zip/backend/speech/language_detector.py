"""
language_detector.py
For voice input, language comes for free from Whisper (see whisper_service.py).
For *text* input (a citizen typing instead of speaking), we still need to
detect the language before routing to the AI pipeline — that's what this
module is for.

Uses `langdetect` (small, pure-python, no model download required) restricted
to the project's supported language set, since langdetect's raw output uses
a much larger language list than we actually support.
"""

from __future__ import annotations

import logging

from langdetect import DetectorFactory, detect_langs

from .whisper_service import SUPPORTED_LANGUAGES

logger = logging.getLogger("speech.language_detector")

# make detection deterministic across runs
DetectorFactory.seed = 0

# langdetect's Bengali/Hindi/Marathi/Tamil/Telugu codes line up with ISO 639-1
# already, but we keep an explicit map in case of drift between library
# versions.
_LANGDETECT_TO_PROJECT = {
    "en": "en",
    "hi": "hi",
    "mr": "mr",
    "ta": "ta",
    "te": "te",
    "bn": "bn",
}


def detect_text_language(text: str, fallback: str = "en") -> tuple[str, float]:
    """Returns (language_code, confidence). Falls back to `fallback`
    (default English) if detection fails or lands outside the supported set.
    """
    text = (text or "").strip()
    if not text:
        return fallback, 0.0

    try:
        candidates = detect_langs(text)
    except Exception as exc:  # langdetect raises LangDetectException on junk input
        logger.warning("Language detection failed for text input: %s", exc)
        return fallback, 0.0

    for candidate in candidates:
        project_code = _LANGDETECT_TO_PROJECT.get(candidate.lang)
        if project_code and project_code in SUPPORTED_LANGUAGES:
            return project_code, float(candidate.prob)

    # top guess wasn't in our supported set at all
    logger.info("Detected language not in supported set, falling back to %s", fallback)
    return fallback, 0.0
