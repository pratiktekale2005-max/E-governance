"""
whisper_service.py
Wraps faster-whisper (CTranslate2 backend) running the "tiny" model on CPU.
This is the only module that touches the actual Whisper model — everything
else in speech/ talks to this through transcribe_audio().

Why faster-whisper over openai-whisper: 4x+ faster on CPU with int8
quantization, which matters a lot on an 8GB RAM box with no GPU.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from functools import lru_cache

import numpy as np
from faster_whisper import WhisperModel

logger = logging.getLogger("speech.whisper_service")

# Supported languages for this project (ISO 639-1 codes used by Whisper)
SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "mr": "Marathi",
    "ta": "Tamil",
    "te": "Telugu",
    "bn": "Bengali",
}


@dataclass
class TranscriptionResult:
    text: str
    language: str
    confidence: float  # 0.0 - 1.0, derived from avg_logprob / language probability

    def to_dict(self) -> dict:
        return {"text": self.text, "language": self.language, "confidence": round(self.confidence, 4)}


@lru_cache(maxsize=1)
def get_model() -> WhisperModel:
    """Loads the Whisper Tiny model once per process. int8 compute type
    keeps RAM usage low; swap to 'int8_float16' if you have a GPU available.
    """
    logger.info("Loading faster-whisper tiny model (CPU, int8)...")
    model = WhisperModel("tiny", device="cpu", compute_type="int8")
    logger.info("Whisper model loaded.")
    return model


def transcribe_audio(audio: np.ndarray, sample_rate: int = 16_000, hint_language: str | None = None) -> TranscriptionResult:
    """Runs STT + language ID on a preprocessed 16kHz mono float32 array.

    hint_language: if the session already has a known preferred language
    (see language_manager.py), pass it here — Whisper will still auto-detect
    but this can stabilize borderline segments. Pass None for full auto-detect.
    """
    model = get_model()

    segments, info = model.transcribe(
        audio,
        language=hint_language,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=300),
        beam_size=5,
    )

    text_parts = []
    avg_logprobs = []
    for segment in segments:
        text_parts.append(segment.text.strip())
        if segment.avg_logprob is not None:
            avg_logprobs.append(segment.avg_logprob)

    full_text = " ".join(p for p in text_parts if p).strip()

    # info.language_probability is Whisper's own confidence in the detected
    # language; blend it with segment-level avg_logprob (mapped 0-1) for a
    # single confidence figure to report to the client.
    lang_prob = float(info.language_probability) if info.language_probability else 0.0
    if avg_logprobs:
        # avg_logprob is typically in [-1, 0]; map to roughly [0, 1]
        logprob_conf = float(np.clip(1.0 + (sum(avg_logprobs) / len(avg_logprobs)), 0.0, 1.0))
        confidence = (lang_prob + logprob_conf) / 2
    else:
        confidence = lang_prob

    detected_language = info.language

    if not full_text:
        logger.warning("Whisper produced empty transcription (likely silence or noise-only clip).")

    return TranscriptionResult(text=full_text, language=detected_language, confidence=confidence)
