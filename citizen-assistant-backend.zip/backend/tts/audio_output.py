"""
audio_output.py
Final leg of the TTS pipeline: takes the raw numpy audio from Parler and
turns it into bytes suitable for an HTTP response (or saving to disk for
debugging/caching).
"""

from __future__ import annotations

import base64
import io

import numpy as np
import soundfile as sf


def encode_wav(audio: np.ndarray, sample_rate: int) -> bytes:
    buf = io.BytesIO()
    sf.write(buf, audio, sample_rate, format="WAV", subtype="PCM_16")
    return buf.getvalue()


def encode_wav_base64(audio: np.ndarray, sample_rate: int) -> str:
    """Used by the JSON endpoints (e.g. /speech/chat) that return audio
    inline alongside text rather than as a raw binary response.
    """
    return base64.b64encode(encode_wav(audio, sample_rate)).decode("ascii")


def save_to_disk(audio: np.ndarray, sample_rate: int, path: str) -> str:
    sf.write(path, audio, sample_rate, format="WAV", subtype="PCM_16")
    return path
