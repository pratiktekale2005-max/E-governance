"""
explainability/confidence.py
Module 4 — Confidence Engine.

Confidence is derived from evidence *quality*, never a guessed
probability. Factors: number of independent matching sources, source
verification status, freshness, retrieval relevance, rule consistency
(no conflicts), and amount of missing citizen-profile information.

Always paired with a plain-language explanation — never shown as a bare
number to the citizen (the internal `score` exists for tuning/debugging).
"""

from __future__ import annotations

from models.confidence import Confidence, ConfidenceLevel
from models.evidence import Evidence


def calculate_confidence(
    evidence: list[Evidence],
    has_conflict: bool,
    any_stale: bool,
    missing_profile_fields: list[str] | None = None,
) -> Confidence:
    missing_profile_fields = missing_profile_fields or []

    if not evidence:
        return Confidence(
            level=ConfidenceLevel.LOW,
            reason="No verified government sources could be retrieved for this query.",
            score=0.0,
        )

    num_sources = len({e.source_url for e in evidence})
    verified_ratio = sum(1 for e in evidence if e.human_verified) / len(evidence)
    avg_relevance = sum(e.relevance_score for e in evidence) / len(evidence)

    # Weighted aggregate in [0, 1]. Two or more independent sources earns
    # full credit for that factor; a conflict or staleness zeroes out its
    # respective factor rather than just nudging the score down slightly.
    score = (
        0.30 * min(num_sources / 2, 1.0)
        + 0.25 * verified_ratio
        + 0.25 * avg_relevance
        + 0.10 * (0.0 if has_conflict else 1.0)
        + 0.10 * (0.0 if any_stale else 1.0)
    )
    score = max(0.0, min(1.0, score - 0.05 * len(missing_profile_fields)))

    reasons: list[str] = []
    if num_sources >= 2:
        reasons.append(f"Information retrieved from {num_sources} official government sources.")
    else:
        reasons.append("Information retrieved from a single official government source.")

    reasons.append(
        "Rules are human verified." if verified_ratio >= 0.5 else "Some rules have not been human verified."
    )
    reasons.append(
        "No conflicting information detected." if not has_conflict else "Conflicting information was found across sources."
    )
    if any_stale:
        reasons.append("Some source data has not been recently verified.")
    if missing_profile_fields:
        reasons.append(f"Missing profile details: {', '.join(missing_profile_fields)}.")

    if has_conflict or score < 0.45:
        level = ConfidenceLevel.LOW
    elif score < 0.75 or any_stale or missing_profile_fields:
        level = ConfidenceLevel.MEDIUM
    else:
        level = ConfidenceLevel.HIGH

    return Confidence(level=level, reason=" ".join(reasons), score=round(score, 3))
