"""
explainability/evidence.py
Module 1 — Evidence Collection.

Turns whatever the RAG retriever returns into structured, validated
Evidence objects for every downstream module (citations, reasoning,
confidence, freshness, conflict detection) to consume.

The RAG retriever itself is owned by another pipeline member per the
architecture diagram (same pluggable-hook pattern used in Week 6's
multilingual/ai_processor.py). This module defines the exact shape it
expects and ships a small mock retriever so the explainability pipeline
is runnable and testable on its own before that module exists.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Callable, Optional

from models.evidence import Evidence

logger = logging.getLogger("explainability.evidence")

# Signature: (query: str, language: str) -> list[dict]
# Each dict should contain at least: scheme_id, chunk_id, source_title,
# source_url. Optional: department, section, page, retrieved_at,
# last_verified, rule_id, relevance_score, human_verified, text.
RagFn = Callable[[str, str], list[dict]]

rag_retriever: Optional[RagFn] = None


def _mock_retriever(query: str, language: str) -> list[dict]:
    """Fallback used until a real RAG retriever is wired in. Returns a
    small, realistic PM-KISAN evidence set so the pipeline is testable
    end-to-end during development.
    """
    logger.warning("No RAG retriever configured — using mock evidence for development/testing.")
    today = date.today().isoformat()
    return [
        {
            "scheme_id": "pm-kisan",
            "chunk_id": "eligibility-001",
            "source_title": "PM-KISAN Portal",
            "source_url": "https://pmkisan.gov.in",
            "department": "Ministry of Agriculture & Farmers Welfare",
            "section": "Eligibility",
            "page": 4,
            "retrieved_at": today,
            "last_verified": "2026-08-07",
            "rule_id": "income-limit",
            "relevance_score": 0.92,
            "human_verified": True,
            "text": "Small and marginal farmer families with combined landholding are eligible, subject to an annual income limit of ₹2 lakh.",
        },
        {
            "scheme_id": "pm-kisan",
            "chunk_id": "eligibility-002",
            "source_title": "MyScheme",
            "source_url": "https://www.myscheme.gov.in",
            "department": "Government of India",
            "section": "Overview",
            "page": None,
            "retrieved_at": today,
            "last_verified": "2026-08-05",
            "rule_id": "occupation-match",
            "relevance_score": 0.85,
            "human_verified": True,
            "text": "PM-KISAN provides income support to all landholding farmer families across the country.",
        },
    ]


def collect_evidence(query: str, language: str) -> list[Evidence]:
    """Runs the configured RAG retriever (or the mock fallback) and returns
    validated Evidence objects. Malformed items are skipped and logged
    rather than failing the whole pipeline.
    """
    fetch = rag_retriever or _mock_retriever
    raw_items = fetch(query, language) or []

    evidence_list: list[Evidence] = []
    for item in raw_items:
        item = dict(item)
        item.setdefault("retrieved_at", date.today().isoformat())
        try:
            evidence_list.append(Evidence(**item))
        except Exception:
            logger.exception("Skipping malformed evidence item: %r", item)

    return evidence_list
