"""
explainability/citations.py
Module 3 — Citation Generator, and Module 8 — Official Link Generator
(folded in here since every official link is just a citation's URL —
no separate state to manage).
"""

from __future__ import annotations

from models.citation import Citation
from models.evidence import Evidence


def generate_citations(evidence: list[Evidence]) -> list[Citation]:
    """Builds one Citation per unique source (deduplicated by URL) from the
    collected evidence. Every factual statement in the response should be
    traceable back to one of these.
    """
    seen_urls: set[str] = set()
    citations: list[Citation] = []

    for item in evidence:
        if item.source_url in seen_urls:
            continue
        seen_urls.add(item.source_url)
        citations.append(
            Citation(
                title=item.source_title,
                department=item.department,
                url=item.source_url,
                section=item.section,
                page=item.page,
                last_verified=item.last_verified,
            )
        )

    return citations


def generate_official_links(citations: list[Citation]) -> list[str]:
    """Prefers official .gov.in domains, per spec ("Always prefer official
    government domains"). Falls back to whatever real URLs are available if
    none are on a .gov.in domain — links are never fabricated.
    """
    official = [c.url for c in citations if ".gov.in" in c.url]
    return official if official else [c.url for c in citations]
