"""
explainability/transparency.py
Module 7 — Transparency Layer.

Builds the plain-language "how this answer was generated" trace shown to
the citizen — the pipeline explaining itself, not just its output.
"""

from __future__ import annotations

from models.evidence import Evidence


def build_trace(evidence: list[Evidence], used_eligibility_engine: bool) -> list[str]:
    trace = ["Government documents retrieved"]
    if used_eligibility_engine:
        trace.append("Eligibility rules evaluated")
    trace.append("Relevant schemes matched" if evidence else "No matching schemes found in retrieved documents")
    trace.append("Response generated using Gemini")
    return trace
