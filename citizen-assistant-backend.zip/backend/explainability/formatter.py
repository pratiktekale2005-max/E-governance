"""
explainability/formatter.py
Module 9 — Explainable Response Formatter.

Combines every explainability component into the single structured
response shape the citizen (and the frontend) actually sees, matching the
response_format JSON in the spec.
"""

from __future__ import annotations

import uuid
from datetime import date

from models.citation import Citation
from models.confidence import Confidence
from models.explanation import ExplainableResponse


def format_response(
    answer: str,
    reasons: list[str],
    sources: list[Citation],
    confidence: Confidence,
    official_links: list[str],
    transparency_trace: list[str],
    scheme_id: str | None = None,
    conflict_warning: str | None = None,
    last_updated: date | None = None,
) -> ExplainableResponse:
    return ExplainableResponse(
        response_id=str(uuid.uuid4()),
        scheme_id=scheme_id,
        answer=answer,
        reason=reasons,
        sources=sources,
        confidence=confidence,
        official_links=official_links,
        last_updated=last_updated or date.today(),
        transparency_trace=transparency_trace,
        conflict_warning=conflict_warning,
    )
