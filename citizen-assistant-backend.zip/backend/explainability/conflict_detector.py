"""
explainability/conflict_detector.py
Module 5 — Source Conflict Detector.

Flags when two or more sources make different numeric claims about the
same rule (e.g. differing income thresholds, per the spec's example).
Surfacing the disagreement to the citizen is far safer than silently
picking one number.
"""

from __future__ import annotations

import re
from collections import defaultdict

from models.evidence import Evidence

CONFLICT_WARNING = (
    "Source Conflict Detected — official sources contain inconsistent information. "
    "Please verify using the latest government notification."
)

# Matches figures like "₹2 lakh", "Rs. 2,00,000", "2.5 lakh", "₹250000"
_AMOUNT_PATTERN = re.compile(
    r"(?:₹|rs\.?\s*)?\s*([\d,]+(?:\.\d+)?)\s*(lakh|crore)?",
    re.IGNORECASE,
)


def _extract_amounts(text: str) -> list[float]:
    """Extracts numeric monetary figures from evidence text, normalized to
    a plain rupee value (lakh/crore expanded), so figures from different
    sources referencing the same rule can be compared directly.
    """
    amounts = []
    for match in _AMOUNT_PATTERN.finditer(text or ""):
        raw_number, unit = match.groups()
        if not raw_number:
            continue
        try:
            value = float(raw_number.replace(",", ""))
        except ValueError:
            continue
        if value == 0:
            continue
        if unit and unit.lower() == "lakh":
            value *= 100_000
        elif unit and unit.lower() == "crore":
            value *= 10_000_000
        amounts.append(value)
    return amounts


def detect_conflicts(evidence: list[Evidence]) -> tuple[bool, str | None, list[dict]]:
    """Groups evidence by rule_id and checks whether extracted numeric
    figures disagree across sources for the same rule.

    Returns (has_conflict, warning_message_or_None, conflict_details).
    """
    by_rule: dict[str, list[Evidence]] = defaultdict(list)
    for item in evidence:
        if item.rule_id and item.text:
            by_rule[item.rule_id].append(item)

    conflicts = []
    for rule_id, items in by_rule.items():
        if len(items) < 2:
            continue
        values_by_source = {item.source_title: _extract_amounts(item.text) for item in items}
        flat_values = {round(v) for vals in values_by_source.values() for v in vals}
        if len(flat_values) > 1:
            conflicts.append({"rule_id": rule_id, "values_by_source": values_by_source})

    if not conflicts:
        return False, None, []

    return True, CONFLICT_WARNING, conflicts
