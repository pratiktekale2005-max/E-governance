"""
explainability/freshness.py
Module 6 — Freshness Checker.

Flags evidence whose last_verified date is older than the staleness
threshold, and produces the citizen-facing stale-data warning when
relevant. Evidence with no last_verified date at all is treated as stale
by default — an unknown verification date is not a "fresh" one.
"""

from __future__ import annotations

from datetime import date, timedelta

from models.evidence import Evidence

STALE_AFTER_DAYS = 180  # ~6 months; tune to how often the underlying schemes actually change

STALE_WARNING = (
    "This information has not been verified recently. "
    "Please check the official portal before applying."
)


def is_stale(evidence: Evidence, today: date | None = None) -> bool:
    today = today or date.today()
    if evidence.last_verified is None:
        return True
    return (today - evidence.last_verified) > timedelta(days=STALE_AFTER_DAYS)


def check_freshness(evidence: list[Evidence], today: date | None = None) -> tuple[bool, str | None]:
    """Returns (any_stale, warning_message_or_None)."""
    stale_items = [e for e in evidence if is_stale(e, today)]
    if not stale_items:
        return False, None
    return True, STALE_WARNING


def most_recent_verification(evidence: list[Evidence]) -> date | None:
    dates = [e.last_verified for e in evidence if e.last_verified is not None]
    return max(dates) if dates else None
