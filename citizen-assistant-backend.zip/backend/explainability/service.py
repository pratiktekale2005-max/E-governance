"""
explainability/service.py
Orchestrates the full explainability pipeline:

  Evidence Collection -> Citation Generation -> Reason Generation ->
  Freshness Check -> Conflict Detection -> Confidence Calculation ->
  Transparency Trace -> Response Formatting

This is what api/explainability.py calls. It also holds an in-memory store
of past ExplainableResponse objects so GET /sources/{scheme_id},
GET /confidence/{response_id}, and GET /citations/{response_id} have
something to look up without re-running the whole pipeline.
"""

from __future__ import annotations

import threading

from models.explanation import ExplainableResponse

from .citations import generate_citations, generate_official_links
from .confidence import calculate_confidence
from .conflict_detector import detect_conflicts
from .evidence import collect_evidence
from .formatter import format_response
from .freshness import check_freshness
from .reasoning import generate_reasons
from .transparency import build_trace

REQUIRED_PROFILE_FIELDS = ["occupation", "state", "income"]


class ExplainabilityStore:
    """In-memory store of generated explanations, keyed by response_id and
    (secondarily) lookup-by-scheme_id for GET /sources/{scheme_id}.

    Swap for a Redis/DB-backed implementation for multi-worker deployment —
    same pattern as memory/session_manager.py in the Week 6 module.
    """

    def __init__(self) -> None:
        self._by_response_id: dict[str, ExplainableResponse] = {}
        self._lock = threading.Lock()

    def save(self, response: ExplainableResponse) -> None:
        with self._lock:
            self._by_response_id[response.response_id] = response

    def get(self, response_id: str) -> ExplainableResponse | None:
        with self._lock:
            return self._by_response_id.get(response_id)

    def get_latest_for_scheme(self, scheme_id: str) -> ExplainableResponse | None:
        with self._lock:
            matches = [r for r in self._by_response_id.values() if r.scheme_id == scheme_id]
            return matches[-1] if matches else None


store = ExplainabilityStore()


def _missing_profile_fields(citizen_profile: dict | None) -> list[str]:
    profile = citizen_profile or {}
    return [f for f in REQUIRED_PROFILE_FIELDS if not profile.get(f)]


def generate_explanation(
    query: str,
    language: str,
    answer_text: str,
    citizen_profile: dict | None = None,
    scheme_id: str | None = None,
) -> ExplainableResponse:
    """Runs the full explainability pipeline for a single (query, answer)
    pair and returns the structured ExplainableResponse, persisting it so
    it can be looked up later via the GET endpoints.

    `answer_text` is the AI's answer — typically produced upstream by
    Week 6's multilingual.ai_processor.generate_response(). This service
    doesn't generate the answer itself; it explains one that already
    exists, matching the "Response generated using Gemini" step shown as
    the final entry in the transparency trace.
    """
    evidence = collect_evidence(query, language)
    if scheme_id:
        filtered = [e for e in evidence if e.scheme_id == scheme_id]
        evidence = filtered or evidence

    reasons = generate_reasons(query, language, citizen_profile, evidence)
    citations = generate_citations(evidence)
    official_links = generate_official_links(citations)

    any_stale, freshness_warning = check_freshness(evidence)
    has_conflict, conflict_warning, _details = detect_conflicts(evidence)

    missing_fields = _missing_profile_fields(citizen_profile)
    confidence = calculate_confidence(evidence, has_conflict, any_stale, missing_fields)

    trace = build_trace(evidence, used_eligibility_engine=True)

    resolved_scheme_id = scheme_id or (evidence[0].scheme_id if evidence else None)

    response = format_response(
        answer=answer_text,
        reasons=reasons,
        sources=citations,
        confidence=confidence,
        official_links=official_links,
        transparency_trace=trace,
        scheme_id=resolved_scheme_id,
        conflict_warning=conflict_warning or freshness_warning,
    )

    store.save(response)
    return response
