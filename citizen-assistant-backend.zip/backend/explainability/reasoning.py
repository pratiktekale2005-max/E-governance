"""
explainability/reasoning.py
Module 2 — Reason Generator.

Explains *why* the AI produced a particular answer. Per the spec, reasons
must only ever reference: retrieved rules, the citizen profile, or official
documents — never an invented explanation.

The eligibility engine is owned by another pipeline member (same pluggable-
hook pattern as evidence.py). This module defines the interface it expects
and falls back to a small mock so the reasoning step is testable standalone.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

from models.evidence import Evidence

logger = logging.getLogger("explainability.reasoning")

# Signature: (query, language, citizen_profile) -> list[dict]
# Each dict: {"criterion": str, "matched": bool, "detail": str}
EligibilityFn = Callable[[str, str, Optional[dict]], list[dict]]

eligibility_engine: Optional[EligibilityFn] = None


def _mock_eligibility(query: str, language: str, citizen_profile: Optional[dict]) -> list[dict]:
    logger.warning("No eligibility engine configured — using mock criteria for development/testing.")
    profile = citizen_profile or {}
    criteria = []

    if str(profile.get("occupation", "")).lower() == "farmer":
        criteria.append({
            "criterion": "Occupation",
            "matched": True,
            "detail": "You selected Farmer as your occupation.",
        })
    if profile.get("state"):
        criteria.append({
            "criterion": "State",
            "matched": True,
            "detail": f"Your state ({profile['state']}) supports this scheme.",
        })
    if profile.get("income") is not None:
        criteria.append({
            "criterion": "Income",
            "matched": True,
            "detail": "Your annual income falls within the published limit.",
        })

    if not criteria:
        criteria.append({
            "criterion": "General eligibility",
            "matched": True,
            "detail": "Your profile matches the published criteria.",
        })

    return criteria


def generate_reasons(
    query: str,
    language: str,
    citizen_profile: Optional[dict],
    evidence: list[Evidence],
) -> list[str]:
    """Returns citizen-facing reason strings, each grounded in either a
    matched eligibility criterion or a piece of retrieved evidence.
    """
    check = eligibility_engine or _mock_eligibility
    matched_criteria = check(query, language, citizen_profile) or []

    reasons = [c["detail"] for c in matched_criteria if c.get("matched") and c.get("detail")]

    # If the eligibility engine gave nothing usable, ground reasons in
    # evidence text instead of fabricating an explanation.
    if not reasons:
        for item in evidence[:3]:
            if item.text:
                reasons.append(f"Supported by {item.source_title}: {item.text}")

    if not reasons:
        reasons.append("This recommendation is based on the retrieved government guidelines for this scheme.")

    return reasons
